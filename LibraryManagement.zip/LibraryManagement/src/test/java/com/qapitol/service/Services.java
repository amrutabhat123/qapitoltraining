package com.qapitol.service;

public interface Services {
    void addStudent();
    void deleteStudent();
    void updateStudent();
    void displayStudent();

    void addBook();
    void deleteBook();
    void updateBook();
    void displayBook();




}
