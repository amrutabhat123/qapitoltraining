package com.qapitol.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.qapitol.module.Books;
import com.qapitol.module.Student;

import java.awt.print.Book;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class ServiceImpliment implements Services {
    Scanner sc=new Scanner(System.in);

    Books b=new Books();
    List<Student > st=new ArrayList<>();
    Student s;
    @Override
    public void addStudent() {
        s=new Student();
        System.out.println("enter a student id");
        int id = sc.nextInt();
        System.out.println("enter a student name");
        String name = sc.next();
        System.out.println("enter a student age");
        int age = sc.nextInt();
        System.out.println("enter a student address");
        String address = sc.next();
        s.setId(id);
        s.setName(name);
        s.setAge(age);
        s.setAddress(address);
        st.add(s);

        File file=new File("C:\\Users\\Qapitol QA\\IdeaProjects\\LibraryManagement\\src\\test\\java\\com\\qapitol\\util\\student.json");
        ObjectMapper om=new ObjectMapper();
        List<Student> lst;
        try {
            lst=om.readValue(file, new TypeReference<List<Student>>() {

            });
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        lst.add(s);
        try {
            om.writerWithDefaultPrettyPrinter().writeValue(file,lst);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


    }

    @Override
    public void deleteStudent() {
        System.out.println("enter id to delete");
        int studentId = sc.nextInt();
        File file=new File("C:\\Users\\Qapitol QA\\IdeaProjects\\LibraryManagement\\src\\test\\java\\com\\qapitol\\util\\student.json");
        boolean found=false;
        ObjectMapper omdel=new ObjectMapper();
        try {
            st = omdel.readValue(file, omdel.getTypeFactory().constructCollectionType(List.class, Student.class));
        }
        catch (IOException e){
            throw new RuntimeException(e);
        }
        Iterator<Student> it = st.iterator();

        while(it.hasNext()){
            Student studentDetails = it.next();
            if(studentDetails.getId()==studentId) {
                it.remove();
                found=true;
                System.out.println("removed successfully");
                break;

            }


        }


     if(!found){
         System.out.println("id not found");
     }

        try {

            omdel.writerWithDefaultPrettyPrinter().writeValue(file,st);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


    }

    @Override
    public void updateStudent() {

       // boolean found=false;
        System.out.println("enter id to update");
        int studentId = sc.nextInt();
        File file=new File("C:\\Users\\Qapitol QA\\IdeaProjects\\LibraryManagement\\src\\test\\java\\com\\qapitol\\util\\student.json");
        boolean found=false;
        ObjectMapper omdel=new ObjectMapper();
        try {
            st = omdel.readValue(file, omdel.getTypeFactory().constructCollectionType(List.class, Student.class));
        }
        catch (IOException e){
            throw new RuntimeException(e);
        }


        for(Student student:st){
            if(student.getId()==studentId){
                System.out.println("Which field do you want to update?");
                System.out.println("1: Name");
                System.out.println("2: Age");
                System.out.println("3: Address");
                int editChoice=sc.nextInt();
                switch (editChoice){
                    case 1:
                        student.setName(sc.next());
                        break;

                    case 2:
                        student.setAge(sc.nextInt());
                    break;
                    case 3:
                        student.setAddress(sc.next());
                        break;
                    default:
                        System.out.println("Invalid choice.");
                        break;


                }

                System.out.println("student updated successfully");
                found=true;
                break;


            }
        }

     if(!found){
         System.out.println("id not found");
     }
     else{
         try {

             omdel.writerWithDefaultPrettyPrinter().writeValue(file,st);
         } catch (IOException e) {
             throw new RuntimeException(e);
         }
     }

    }

    @Override
    public void displayStudent() {
    // s.toString(); //  System.out.println("id"+s.getId()+"name"+s.getName()+"age"+s.getAge()+"Address"+s.getAddress());
    for(int i=0;i<st.size();i++){
        System.out.println(st.get(i));
    }



    }

    @Override
    public void addBook() {
        System.out.println("enter a book id");
        int id = sc.nextInt();
        System.out.println("enter a book name");
        String name = sc.next();
        System.out.println("enter a book author");
        String  author= sc.next();
        b.setId(id);
        b.setName(name);
        b.setAuthor(author);




    }

    @Override
    public void deleteBook() {

    }

    @Override
    public void updateBook() {

    }

    @Override
    public void displayBook() {

    }
}
